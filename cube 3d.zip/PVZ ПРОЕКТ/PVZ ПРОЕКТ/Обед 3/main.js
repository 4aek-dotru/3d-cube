// === 1. ПОЛУЧЕНИЕ ЭЛЕМЕНТОВ DOM ===
let BUTT = document.querySelectorAll('.usil');
let Butt_Sec = document.querySelectorAll('.usil_sec');
let countOfCoins = document.getElementById('count');

// Функция для подставки ' , ' в числах, для улучшения чисел
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

// === 2. ЗАГРУЗКА ИЗ LOCALSTORAGE ===
let currentLevelNewGame = parseInt(localStorage.getItem('LevelNewGame')) || 1;
let currentCostNewGame = parseInt(localStorage.getItem('CostNewGame')) || 500000;
let BBC = JSON.parse(localStorage.getItem('BaseButtonCosts')) || {};
let BBCS = JSON.parse(localStorage.getItem('BaseButtonCostsSec')) || {};
let currentPower = parseInt(localStorage.getItem('currentPower'), 10) || 1;
let currentPowerSec = parseInt(localStorage.getItem('currentPowerSec'), 10) || 0;
let Coins = parseInt(localStorage.getItem('coins'), 10) || 0;
let allGardens = localStorage.getItem('Garden');

// === 3. ИНИЦИАЛИЗАЦИЯ БАЗОВЫХ ЦЕН ===
if (Object.keys(BBC).length === 0) {
    const baseCosts = {};
    BUTT.forEach((btn, idx) => {
        baseCosts[idx] = parseFloat(btn.dataset.cost);
    });
    localStorage.setItem('BaseButtonCosts', JSON.stringify(baseCosts));
    BBC = baseCosts;
}

if (Object.keys(BBCS).length === 0) {
    const baseCostsSec = {};
    Butt_Sec.forEach((btn, idx) => {
        baseCostsSec[idx] = parseFloat(btn.dataset.cost);
    });
    localStorage.setItem('BaseButtonCostsSec', JSON.stringify(baseCostsSec));
    BBCS = baseCostsSec;
}

// === 4. ОБНОВЛЕНИЕ ИНТЕРФЕЙСА ===
document.getElementById('on-click').innerText = `${formatNumber(currentPower)}$ за клик`;
document.getElementById('on-sec').innerText = `${formatNumber(currentPowerSec)}$ в сек.`;
countOfCoins.innerText = `${formatNumber(Coins)}$`;
document.getElementById('new-game-cost').innerText = `${formatNumber(currentCostNewGame)}$`
if(allGardens !== null) {
    document.getElementById(`all-plants-container`).innerHTML = `${allGardens}`
}

// === 5. ФУНКЦИИ ===
function everySecond() {
    setInterval(() => {
        Coins = (parseInt(localStorage.getItem('coins'), 10) || 0) + (parseInt(localStorage.getItem('currentPowerSec'), 10) || 0);
        countOfCoins.innerText = `${formatNumber(Coins)}$`;
        localStorage.setItem('coins', Coins);
    }, 1000);
}

function saveGameState() {
    // Сохранение для кликовых улучшений
    const costs = {};
    const levels = {};
    BUTT.forEach((btn, idx) => {
        costs[idx] = parseFloat(btn.dataset.cost);
        levels[idx] = parseInt(btn.dataset.level, 10) || 0;
    });
    
    // Сохранение для секундных улучшений
    const costsSec = {};
    const levelsSec = {};
    Butt_Sec.forEach((btn, idx) => {
        costsSec[idx] = parseFloat(btn.dataset.cost);
        levelsSec[idx] = parseInt(btn.dataset.level, 10) || 0;
    });
    
    localStorage.setItem('coins', Coins);
    localStorage.setItem('currentPower', currentPower);
    localStorage.setItem('currentPowerSec', currentPowerSec);
    localStorage.setItem('buttonCosts', JSON.stringify(costs));
    localStorage.setItem('buttonLevel', JSON.stringify(levels));
    localStorage.setItem('buttonCostsSec', JSON.stringify(costsSec));
    localStorage.setItem('buttonLevelSec', JSON.stringify(levelsSec));
}

// === 6. ОБРАБОТЧИКИ СОБЫТИЙ ===

// Клик по основной кнопке
document.getElementById('click-container').addEventListener('click', function() {
    Coins = parseInt(Coins, 10) + parseInt(currentPower, 10);
    countOfCoins.innerText = `${formatNumber(Coins)}$`;
    localStorage.setItem('coins', Coins);
});

// Обработчики для кнопок улучшения клика
BUTT.forEach((button, index) => {
    // Загрузка сохраненных данных
    const savedLevels = JSON.parse(localStorage.getItem('buttonLevel')) || {};
    const savedCosts = JSON.parse(localStorage.getItem('buttonCosts')) || {};
    
    // Инициализация кнопки
    if (savedCosts[index] !== undefined) {
        button.dataset.cost = savedCosts[index];
        button.dataset.level = savedLevels[index] || 0;
    } else {
        // Первый запуск
        button.dataset.cost = BBC[index] || button.dataset.cost;
        button.dataset.level = 0;
    }

    // Изменяем мощь кнопки в зависимости от уровня игры
    button.dataset.power = button.dataset.power * currentLevelNewGame;
    // Сохраняем базовую цену
    button.dataset.baseCost = BBC[index] || parseFloat(button.dataset.cost);
    // Обновляем текст кнопки
    button.innerHTML = `<img id='image-${button.dataset.name}' src='img/${button.dataset.name}.png'></img>
        <div id='info-${button.dataset.name}'>
            <h3>${button.dataset.name}</h3>
            <p>${formatNumber(button.dataset.power)}</p>
            <p>${formatNumber(button.dataset.cost)}</p>
        </div>
        <div id='level-${button.dataset.name}'>
            <h2>${formatNumber(button.dataset.level)}</h2>
        </div>`
    
    // Обработчик клика
    button.addEventListener('click', function() {
        const currentCost = parseInt(button.dataset.cost, 10);
        const currentLevel = parseInt(button.dataset.level, 10);
        const baseCost = parseFloat(button.dataset.baseCost);
        
        if (currentCost > Coins) {
            let id = 'alert_' + Date.now();
            const alertDiv = document.createElement('div');
            alertDiv.classList.add('alert-text', id); 
            alertDiv.textContent = 'Недостаточно средств';
            document.getElementById('alert').appendChild(alertDiv);

            setTimeout(() => {
                alertDiv.classList.add('hidden');
                setTimeout(() => {
                    alertDiv.remove();
                }, 500);
            }, 3000);
            return;
        }
        
        // Списываем деньги
        Coins -= currentCost;
        countOfCoins.innerText = `${formatNumber(Coins)}$`;
        
        // Увеличиваем силу клика
        currentPower += parseInt(button.dataset.power, 10);
        document.getElementById('on-click').innerText = `${formatNumber(currentPower)}$ за клик`;
        
        // Повышаем уровень
        const newLevel = currentLevel + 1;
        button.dataset.level = newLevel;
        
        // Рассчитываем новую цену: базовая цена × 1.3^уровень
        const newCost = Math.round(baseCost * Math.pow(1.3, newLevel));
        button.dataset.cost = newCost;

        button.innerHTML = `<img id='image-${button.dataset.name}' src='img/${button.dataset.name}.png'></img>
        <div id='info-${button.dataset.name}'>
            <h3>${button.dataset.name}</h3>
            <p>${formatNumber(button.dataset.power)}</p>
            <p>${formatNumber(button.dataset.cost)}</p>
        </div>
        <div id='level-${button.dataset.name}'>
            <h2>${formatNumber(button.dataset.level)}</h2>
        </div>`
        addPlant(button)
        // Сохраняем состояние
        saveGameState();
    });
});

// Обработчики для кнопок пассивного заработка
Butt_Sec.forEach((button, index) => {
    // Загрузка сохраненных данных
    const savedLevelsSec = JSON.parse(localStorage.getItem('buttonLevelSec')) || {};
    const savedCostsSec = JSON.parse(localStorage.getItem('buttonCostsSec')) || {};
    
    // Инициализация кнопки
    if (savedCostsSec[index] !== undefined) {
        button.dataset.cost = savedCostsSec[index];
        button.dataset.level = savedLevelsSec[index] || 0;
    } else {
        // Первый запуск
        button.dataset.cost = BBCS[index] || button.dataset.cost;
        button.dataset.level = 0;
    }

    // Изменяем мощь кнопки в зависимости от уровня игры
    button.dataset.power = button.dataset.power * currentLevelNewGame;
    // Сохраняем базовую цену
    button.dataset.baseCost = BBCS[index] || parseFloat(button.dataset.cost);
    
    // Обновляем текст кнопки
    button.innerHTML = `<img id='image-${button.dataset.name}' src='img/${button.dataset.name}.png'></img>
        <div id='info-${button.dataset.name}'>
            <h3>${button.dataset.name}</h3>
            <p>${formatNumber(button.dataset.power)}</p>
            <p>${formatNumber(button.dataset.cost)}</p>
        </div>
        <div id='level-${button.dataset.name}'>
            <h2>${formatNumber(button.dataset.level)}</h2>
        </div>`

    // Обработчик клика
    button.addEventListener('click', function() {
        const currentCost = parseInt(button.dataset.cost, 10);
        const currentLevel = parseInt(button.dataset.level, 10);
        const baseCost = parseFloat(button.dataset.baseCost);
        let allPlantsOnGarden = document.querySelectorAll(`.${button.dataset.name}, .${button.dataset.pastname}`);

        if (currentCost > Coins) {
            let id = 'alert_' + Date.now();
            const alertDiv = document.createElement('div');
            alertDiv.classList.add('alert-text', id); 
            alertDiv.textContent = 'Недостаточно средств';
            document.getElementById('alert').appendChild(alertDiv);

            setTimeout(() => {
                alertDiv.classList.add('hidden');
                setTimeout(() => {
                    alertDiv.remove();
                }, 500);
            }, 3000);
            return;
        }
        if(allPlantsOnGarden.length < 5){
            if(allPlantsOnGarden.length === currentLevel){
                let id = 'alert_' + Date.now();
                const alertDiv = document.createElement('div');
                alertDiv.classList.add('alert-text', id); 
                alertDiv.textContent = 'Нет растения для улучшения!';
                document.getElementById('alert').appendChild(alertDiv);

                setTimeout(() => {
                    alertDiv.classList.add('hidden');
                    setTimeout(() => {
                        alertDiv.remove();
                    }, 500);
                }, 3000);
                return
            }
        }

        // Списываем деньги
        Coins -= currentCost;
        countOfCoins.innerText = `${formatNumber(Coins)}$`;

        // Увеличиваем пассивный доход
        currentPowerSec += parseInt(button.dataset.power, 10);
        document.getElementById('on-sec').innerText = `${formatNumber(currentPowerSec)}$ в сек.`;

        // Повышаем уровень
        const newLevel = currentLevel + 1;
        button.dataset.level = newLevel;

        // Рассчитываем новую цену
        const newCost = Math.round(baseCost * Math.pow(1.3, newLevel));
        button.dataset.cost = newCost;
        button.innerHTML = `<img id='image-${button.dataset.name}' src='img/${button.dataset.name}.png'></img>
        <div id='info-${button.dataset.name}'>
            <h3>${button.dataset.name}</h3>
            <p>${formatNumber(button.dataset.power)}</p>
            <p>${formatNumber(button.dataset.cost)}</p>
        </div>
        <div id='level-${button.dataset.name}'>
            <h2>${formatNumber(button.dataset.level)}</h2>
        </div>`

        // Улучшение растения на грядке
        upPlant(button);

        // Сохраняем состояние
        saveGameState();
    });
});
// Восхождение
document.getElementById("new-game").addEventListener('click', function() {
    // Проверка количества денег
    if(Coins < currentCostNewGame){
        window.location.replace('error.html')
        return
    }
    // Получение новых значений Уровня игры и Цены новой игры
    newLevelNewGame = currentLevelNewGame + 1;
    newCostNewGame = (Math.round(500000 * Math.pow(1.3, newLevelNewGame)));
    
    // Очищение localStorage с последующей записью новых значений
    localStorage.clear();
    localStorage.setItem('CostNewGame', newCostNewGame)
    localStorage.setItem('LevelNewGame', newLevelNewGame)

    window.location.reload()
})

// Сохранение HTML со всеми грядками и растениями в localStorage
function savePlantsToStorage() {
    let allGarden = document.getElementById(`all-plants-container`).innerHTML;
    localStorage.setItem('Garden', allGarden);
} 

// Добавление растения на грядку
function addPlant(button) {
    // Проверка на максимальное допустимое количество растений на грядке
    if(document.getElementById(`garden-${button.dataset.name}`).children.length < 5){
        
        // Добавляем растение
        document.getElementById(`garden-${button.dataset.name}`).innerHTML += `<div style="width: 110px; height: 110px;"><img class="${button.dataset.name}" src='img/${button.dataset.name}.gif'></img></div>`
        savePlantsToStorage()
    }
}

// Улучшение растений на грядке
function upPlant(button){
    // Получаю все растения, которые есть на грядке
    let allPlantsOnGarden = document.querySelectorAll(`.${button.dataset.name}, .${button.dataset.pastname}`);

    // Если все растения прокачены, то скип
    if(document.querySelectorAll(`.${button.dataset.pastname}`) === undefined){
        return
    }

    allPlantsOnGarden.forEach((plant, index ) => {
        // Проделываем операцию только с нужными растениями
        if(index < button.dataset.level) {
            // Работаем только с неизменёнными растениями
            if(plant.classList.contains(`${button.dataset.pastname}`)) {
                // Изменяем класс необходимых растений
                plant.classList.replace(`${button.dataset.pastname}`, `${button.dataset.name}`)
                plant.src = `img/${button.dataset.name}.gif`

                savePlantsToStorage()
            }else return
        }
    })
}
// === 7. ЗАПУСК ИГРЫ ===
everySecond(); // Запускаем пассивный доход