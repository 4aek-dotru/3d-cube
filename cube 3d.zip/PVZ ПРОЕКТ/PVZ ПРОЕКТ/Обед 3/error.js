document.getElementById('back-to-game').onclick = e => {
    window.location.replace('index.html')
}